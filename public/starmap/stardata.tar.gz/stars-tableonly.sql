-- MySQL dump 8.23
--
-- Host: localhost    Database: stars
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `tblGalactic`
--

CREATE TABLE tblGalactic (
  StarID int(11) NOT NULL default '0',
  X float NOT NULL default '0',
  Y float NOT NULL default '0',
  Z float NOT NULL default '0',
  PRIMARY KEY  (StarID)
) TYPE=MyISAM;

--
-- Table structure for table `tblHYG`
--

CREATE TABLE tblHYG (
  StarID int(11) NOT NULL default '0',
  Hip int(11) NOT NULL default '0',
  HD int(11) NOT NULL default '0',
  HR int(11) NOT NULL default '0',
  Gliese varchar(16) default NULL,
  BayerFlam varchar(16) default NULL,
  ProperName varchar(16) default NULL,
  RA double default NULL,
  Declination double default NULL,
  Distance float default NULL,
  Mag float default NULL,
  AbsMag float default NULL,
  Spectrum varchar(16) default NULL,
  ColorIndex float default NULL,
  PRIMARY KEY  (StarID,StarID)
) TYPE=MyISAM;

--
-- Table structure for table `tblStarTrek`
--

CREATE TABLE tblStarTrek (
  StarID int(11) NOT NULL default '0',
  Name varchar(32) NOT NULL default '',
  PRIMARY KEY  (StarID)
) TYPE=MyISAM;

